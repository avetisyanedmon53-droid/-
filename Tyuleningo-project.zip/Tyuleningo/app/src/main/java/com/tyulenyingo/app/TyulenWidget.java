package com.tyulenyingo.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TyulenWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    public static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, TyulenWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    private static String word(int n) {
        if (n == 1) return "день";
        if (n > 1 && n < 5) return "дня";
        return "дней";
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences("w", Context.MODE_PRIVATE);
        int streak = p.getInt("streak", 0);
        String last = p.getString("last", "");

        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Calendar cal = Calendar.getInstance();
        String today = f.format(cal.getTime());
        cal.add(Calendar.DAY_OF_MONTH, -1);
        String yesterday = f.format(cal.getTime());

        boolean done = last.equals(today);
        boolean alive = done || last.equals(yesterday);
        int n = alive ? streak : 0;

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setImageViewResource(R.id.flame, done ? R.drawable.flame_on : R.drawable.flame_off);
        v.setTextViewText(R.id.days, n + " " + word(n));
        v.setTextViewText(R.id.phrase, p.getString("ph", "Keep going! · Так держи!"));
        v.setTextViewText(R.id.status, done ? "На сегодня готово ✅" : "Огонь ждёт урока");

        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.root, pi);
        return v;
    }
}
