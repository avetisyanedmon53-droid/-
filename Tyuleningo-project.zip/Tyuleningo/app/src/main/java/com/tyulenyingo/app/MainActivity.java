package com.tyulenyingo.app;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private boolean offline = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(getApplicationContext()), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // нет интернета или неверный адрес сайта: открываем встроенную копию игры
                if (r.isForMainFrame() && !offline) {
                    offline = true;
                    v.loadUrl("file:///android_asset/index.html");
                }
            }
        });
        web.loadUrl(getString(R.string.site_url));
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    /** Мост: сайт на Netlify сообщает виджету, сколько дней подряд. */
    public static class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c; }

        @JavascriptInterface
        public void setStreak(int streak, String lastYmd, String phrase, String phraseRu) {
            ctx.getSharedPreferences("w", Context.MODE_PRIVATE).edit()
                .putInt("streak", streak)
                .putString("last", lastYmd == null ? "" : lastYmd)
                .putString("ph", phrase + " · " + phraseRu)
                .apply();
            TyulenWidget.refresh(ctx);
        }
    }
}
